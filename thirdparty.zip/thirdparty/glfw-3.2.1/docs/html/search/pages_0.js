var searchData=
[
  ['bug_20list',['Bug List',['../bug.html',1,'']]],
  ['building_20applications',['Building applications',['../build_guide.html',1,'']]]
];
